# MAGEG COMPANY LIMITED - Website Code

This document contains the HTML/CSS code for the four screens of the MAGEG COMPANY LIMITED website.

---

## 1. Home Page
**Title:** Home - MAGEG COMPANY LIMITED
**Device:** Desktop

```html
{{DATA:SCREEN:SCREEN_4}}
```

---

## 2. Services Page
**Title:** Huduma Zetu - MAGEG COMPANY LIMITED
**Device:** Desktop

```html
{{DATA:SCREEN:SCREEN_5}}
```

---

## 3. Projects & Testimonials Page
**Title:** Miradi na Ushuhuda - MAGEG COMPANY LIMITED
**Device:** Desktop

```html
{{DATA:SCREEN:SCREEN_6}}
```

---

## 4. Contact Us Page
**Title:** Wasiliana Nasi - MAGEG COMPANY LIMITED
**Device:** Desktop

```html
{{DATA:SCREEN:SCREEN_2}}
```
