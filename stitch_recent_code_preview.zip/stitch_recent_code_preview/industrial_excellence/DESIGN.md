---
name: Industrial Excellence
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#3e4850'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#6e7881'
  outline-variant: '#bec8d2'
  surface-tint: '#006591'
  primary: '#006591'
  on-primary: '#ffffff'
  primary-container: '#0ea5e9'
  on-primary-container: '#003751'
  inverse-primary: '#89ceff'
  secondary: '#bb0112'
  on-secondary: '#ffffff'
  secondary-container: '#e02928'
  on-secondary-container: '#fffbff'
  tertiary: '#735c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#cea700'
  on-tertiary-container: '#4e3e00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c9e6ff'
  primary-fixed-dim: '#89ceff'
  on-primary-fixed: '#001e2f'
  on-primary-fixed-variant: '#004c6e'
  secondary-fixed: '#ffdad6'
  secondary-fixed-dim: '#ffb4ab'
  on-secondary-fixed: '#410002'
  on-secondary-fixed-variant: '#93000b'
  tertiary-fixed: '#ffe083'
  tertiary-fixed-dim: '#eec200'
  on-tertiary-fixed: '#231b00'
  on-tertiary-fixed-variant: '#574500'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-xl:
    fontFamily: Work Sans
    fontSize: 60px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Work Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Work Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Public Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Public Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-bold:
    fontFamily: Public Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  container-max: 1280px
  gutter: 24px
---

## Brand & Style

This design system is built to project the reliability of a global logistics firm with the meticulous precision of a specialized cleaning and repair service. The brand personality is **authoritative, energetic, and highly organized**. It strikes a balance between industrial robustness and modern corporate sophistication.

The visual style follows a **Modern Corporate** aesthetic. It utilizes high-contrast color blocking to differentiate service sectors while maintaining a unified, high-fidelity look. Imagery should focus on "macro" excellence—gleaming machinery, organized logistics hubs, and spotless environments—rendered with high clarity and natural lighting. The interface is characterized by generous white space, crisp borders, and a logical information hierarchy that builds immediate trust with B2B and B2C clients.

## Colors

The color strategy is designed for high-impact communication and clarity across diverse service lines.

*   **Sky Blue (Primary):** Used as the foundation for trust and modernity. It dominates the navigation and primary action states, symbolizing the "Logistics" and "Modernity" aspects of the company.
*   **Red (Accent):** Reserved for critical call-to-actions, alerts, and highlighting urgent logistics updates. It provides a high-energy contrast against the blue.
*   **Yellow (Highlight):** Used sparingly to draw attention to status indicators, "Energy" services, or special offers. It acts as a vibrant visual hook.
*   **White (Background):** The primary canvas color, emphasizing the "Cleaning & Fumigation" aspect of the business through a sense of sterility and order.
*   **Black (Text):** A sophisticated deep slate-black is used for all typography to ensure maximum readability and a premium corporate feel.

## Typography

This design system utilizes two distinct typefaces to achieve a balance between impact and utility.

*   **Work Sans** is used for headlines. Its slightly wider apertures and robust geometric construction feel industrial and dependable. Bold weights are preferred for service titles to project strength.
*   **Public Sans** is utilized for body copy and UI labels. As an institutional typeface, it offers exceptional readability at small sizes, making it ideal for the detailed service descriptions and logistical data tables required by the company.

Letter spacing is tightened for large headings to create a "locked-in" professional look, while labels utilize slight tracking to improve legibility in all-caps scenarios.

## Layout & Spacing

The layout is built on a **12-column fixed grid** for desktop, transitioning to a fluid model for mobile. A strict **8px spacing scale** governs all spatial relationships to maintain mathematical harmony and an "engineered" feel.

Margins are generous (48px+) to allow the brand's photography to breathe. Sections are divided by clear horizontal whitespace rather than decorative lines, emphasizing the "clean" aspect of the service portfolio. Component padding is internal and consistent, ensuring that data-heavy logistics cards remain scannable.

## Elevation & Depth

To maintain a "high-fidelity" and "reliable" feel, depth is conveyed through **Tonal Layers** and **Ambient Shadows**.

*   **Surface Tiers:** Backgrounds are kept at pure white, while "Cards" or "Service Modules" use a very subtle light-gray stroke (1px) or a faint Sky Blue tint to lift them from the page.
*   **Shadows:** When used, shadows are highly diffused with low opacity (e.g., 4% alpha Black) to suggest a subtle lift without appearing "game-like" or informal.
*   **Interactive Depth:** On hover, components should transition with a slight increase in shadow spread and a subtle upward shift (2px), mimicking a physical click or a tactile response.

## Shapes

The shape language is **Soft (Level 1)**. Elements utilize a 0.25rem (4px) base radius.

This subtle rounding avoids the aggression of sharp 90-degree corners while steering clear of the overly "playful" nature of pill-shaped buttons. It suggests precision, engineering, and organized structure. Large containers (like Hero sections) may use larger radii (12px) to frame imagery, but functional UI components like inputs and buttons remain strictly within the Soft radius scale.

## Components

Components are designed to feel like high-quality industrial tools: functional, durable, and clear.

*   **Buttons:** Primary buttons are Sky Blue with White text. Secondary buttons use a thick 2px Black border. The "Action" button for emergency repairs or fumigation requests uses the Red accent.
*   **Service Cards:** Large cards featuring high-resolution industrial photography at the top, followed by a Work Sans bold heading and a concise Public Sans description.
*   **Inputs:** High-contrast fields with 1px Black borders that turn Sky Blue on focus. Error states are clearly marked with the Accent Red.
*   **Status Chips:** Used for tracking logistics. These utilize the Yellow highlight for "In Progress," Sky Blue for "Dispatched," and Green (system color) for "Delivered."
*   **Data Tables:** Essential for General Supply lists. These use alternating row tints and bold Work Sans headers for column titles to ensure clarity in dense information.
*   **Iconography:** Linear, 2px stroke icons in Black or Sky Blue. Icons should be literal and professional (e.g., a real truck silhouette for logistics, a precise wrench for repair).